import { MainApp } from "@/main/index";

const Index = () => {
  return <MainApp />;
};

export default Index;
