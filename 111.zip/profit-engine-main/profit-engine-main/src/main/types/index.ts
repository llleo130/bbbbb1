export interface Startup {
  id: string;
  name: {
    en: string;
    ru: string;
  };
  description: {
    en: string;
    ru: string;
  };
  monthlyProfit: string;
  category: {
    en: string;
    ru: string;
  };
  analytics: {
    marketSize: string;
    competition: 'Low' | 'Medium' | 'High';
    investmentRequired: string;
    timeToProfit: string;
    growthPotential: number; // 1-10 scale
    riskLevel: 'Low' | 'Medium' | 'High';
  };
}

export type Language = 'en' | 'ru';

export interface LanguageContextType {
  language: Language;
  toggleLanguage: () => void;
  t: (key: string) => string;
}