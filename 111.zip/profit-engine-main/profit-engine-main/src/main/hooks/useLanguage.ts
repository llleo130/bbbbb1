import { useState, createContext, useContext } from 'react';
import { Language, LanguageContextType } from '../types';

const translations = {
  en: {
    // Header
    title: 'StartX',
    subtitle: 'Generator of current and profitable startup ideas for modern entrepreneurs',
    
    // Buttons
    generateStartup: 'Create Startup',
    anotherStartup: 'Another Startup',
    generating: 'Generating startup...',
    
    // Startup Card
    projectDescription: 'Project Description:',
    expectedMonthlyProfit: 'Expected Monthly Profit:',
    analytics: 'Analytics',
    
    // Analytics
    marketSize: 'Market Size',
    competition: 'Competition',
    investmentRequired: 'Investment Required',
    timeToProfit: 'Time to Profit',
    growthPotential: 'Growth Potential',
    riskLevel: 'Risk Level',
    
    // Competition levels
    low: 'Low',
    medium: 'Medium', 
    high: 'High',
    
    // Features
    innovativeIdeas: 'Innovative Ideas',
    innovativeDesc: 'Only current technologies and trends',
    profitableSolutions: 'Profitable Solutions',
    profitableDesc: 'Real revenue figures and monetization',
    marketOpportunities: 'Market Opportunities',
    marketDesc: 'Analysis of potential and growth prospects',
    
    // Additional Features
    favorites: 'Favorites',
    addToFavorites: 'Add to Favorites',
    removeFromFavorites: 'Remove from Favorites',
    businessPlan: 'Business Plan',
    viewBusinessPlan: 'View Business Plan',
    investmentCalculator: 'Investment Calculator',
    
    // Categories
    'AI & Cleaning': 'AI & Cleaning',
    'FoodTech': 'FoodTech',
    'HealthTech & VR': 'HealthTech & VR',
    'EdTech & Crypto': 'EdTech & Crypto',
    'IoT & Pets': 'IoT & Pets',
    'GreenTech': 'GreenTech',
    'E-commerce AI': 'E-commerce AI',
    'Marketplace': 'Marketplace',
    'FinTech': 'FinTech',
    'SocialTech': 'SocialTech'
  },
  ru: {
    // Header
    title: 'StartX',
    subtitle: 'Генератор актуальных и прибыльных стартап-идей для современных предпринимателей',
    
    // Buttons
    generateStartup: 'Создать стартап',
    anotherStartup: 'Другой стартап',
    generating: 'Генерируем стартап...',
    
    // Startup Card
    projectDescription: 'Описание проекта:',
    expectedMonthlyProfit: 'Ожидаемая прибыль в месяц:',
    analytics: 'Аналитика',
    
    // Analytics
    marketSize: 'Размер рынка',
    competition: 'Конкуренция',
    investmentRequired: 'Требуемые инвестиции',
    timeToProfit: 'Время до прибыли',
    growthPotential: 'Потенциал роста',
    riskLevel: 'Уровень риска',
    
    // Competition levels
    low: 'Низкая',
    medium: 'Средняя',
    high: 'Высокая',
    
    // Features
    innovativeIdeas: 'Инновационные идеи',
    innovativeDesc: 'Только актуальные технологии и тренды',
    profitableSolutions: 'Прибыльные решения',
    profitableDesc: 'Реальные цифры дохода и монетизации',
    marketOpportunities: 'Рыночные возможности',
    marketDesc: 'Анализ потенциала и перспектив роста',
    
    // Additional Features
    favorites: 'Избранное',
    addToFavorites: 'Добавить в избранное',
    removeFromFavorites: 'Удалить из избранного',
    businessPlan: 'Бизнес-план',
    viewBusinessPlan: 'Посмотреть бизнес-план',
    investmentCalculator: 'Калькулятор инвестиций',
    
    // Categories
    'AI & Cleaning': 'ИИ и Уборка',
    'FoodTech': 'ФудТех',
    'HealthTech & VR': 'МедТех и VR',
    'EdTech & Crypto': 'ОбразТех и Крипто',
    'IoT & Pets': 'IoT и Животные',
    'GreenTech': 'ЗеленыеТех',
    'E-commerce AI': 'E-commerce ИИ',
    'Marketplace': 'Маркетплейс',
    'FinTech': 'ФинТех',
    'SocialTech': 'СоцТех'
  }
};

export const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};

export const useLanguageState = () => {
  const [language, setLanguage] = useState<Language>('en');

  const toggleLanguage = () => {
    setLanguage(prev => prev === 'en' ? 'ru' : 'en');
  };

  const t = (key: string): string => {
    const keys = key.split('.');
    let value: any = translations[language];
    
    for (const k of keys) {
      value = value?.[k];
    }
    
    return value || key;
  };

  return { language, toggleLanguage, t };
};