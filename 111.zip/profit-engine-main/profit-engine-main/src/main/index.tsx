import React from 'react';
import { StartupGenerator } from './components/StartupGenerator';
import { LanguageContext, useLanguageState } from './hooks/useLanguage';

export const MainApp = () => {
  const languageState = useLanguageState();

  return (
    <LanguageContext.Provider value={languageState}>
      <StartupGenerator />
    </LanguageContext.Provider>
  );
};