import { BarChart3, TrendingUp, AlertTriangle, Target, Clock, DollarSign } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Startup } from "../types";
import { useLanguage } from "../hooks/useLanguage";

interface AnalyticsProps {
  startup: Startup;
}

export const Analytics = ({ startup }: AnalyticsProps) => {
  const { t } = useLanguage();

  const getCompetitionColor = (level: string) => {
    switch (level) {
      case 'Low': return 'bg-green-500';
      case 'Medium': return 'bg-yellow-500';
      case 'High': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  const getRiskColor = (level: string) => {
    switch (level) {
      case 'Low': return 'text-green-400';
      case 'Medium': return 'text-yellow-400';
      case 'High': return 'text-red-400';
      default: return 'text-gray-400';
    }
  };

  return (
    <Card className="p-6 bg-gradient-card border-border/50 mt-6">
      <div className="flex items-center space-x-2 mb-4">
        <BarChart3 className="h-5 w-5 text-primary" />
        <h3 className="text-lg font-semibold text-foreground">{t('analytics')}</h3>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {/* Market Size */}
        <div className="space-y-2">
          <div className="flex items-center space-x-2">
            <Target className="h-4 w-4 text-primary" />
            <span className="text-sm font-medium text-foreground">{t('marketSize')}</span>
          </div>
          <p className="text-xl font-bold text-primary">{startup.analytics.marketSize}</p>
        </div>

        {/* Competition */}
        <div className="space-y-2">
          <div className="flex items-center space-x-2">
            <TrendingUp className="h-4 w-4 text-primary" />
            <span className="text-sm font-medium text-foreground">{t('competition')}</span>
          </div>
          <Badge className={`${getCompetitionColor(startup.analytics.competition)} text-white`}>
            {t(startup.analytics.competition.toLowerCase())}
          </Badge>
        </div>

        {/* Investment Required */}
        <div className="space-y-2">
          <div className="flex items-center space-x-2">
            <DollarSign className="h-4 w-4 text-primary" />
            <span className="text-sm font-medium text-foreground">{t('investmentRequired')}</span>
          </div>
          <p className="text-lg font-semibold text-foreground">{startup.analytics.investmentRequired}</p>
        </div>

        {/* Time to Profit */}
        <div className="space-y-2">
          <div className="flex items-center space-x-2">
            <Clock className="h-4 w-4 text-primary" />
            <span className="text-sm font-medium text-foreground">{t('timeToProfit')}</span>
          </div>
          <p className="text-lg font-semibold text-foreground">{startup.analytics.timeToProfit}</p>
        </div>

        {/* Growth Potential */}
        <div className="space-y-2">
          <div className="flex items-center space-x-2">
            <TrendingUp className="h-4 w-4 text-primary" />
            <span className="text-sm font-medium text-foreground">{t('growthPotential')}</span>
          </div>
          <div className="space-y-1">
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">{startup.analytics.growthPotential}/10</span>
            </div>
            <Progress value={startup.analytics.growthPotential * 10} className="h-2" />
          </div>
        </div>

        {/* Risk Level */}
        <div className="space-y-2">
          <div className="flex items-center space-x-2">
            <AlertTriangle className="h-4 w-4 text-primary" />
            <span className="text-sm font-medium text-foreground">{t('riskLevel')}</span>
          </div>
          <p className={`text-lg font-semibold ${getRiskColor(startup.analytics.riskLevel)}`}>
            {t(startup.analytics.riskLevel.toLowerCase())}
          </p>
        </div>
      </div>
    </Card>
  );
};