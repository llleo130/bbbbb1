import { Languages } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useLanguage } from "../hooks/useLanguage";

export const LanguageToggle = () => {
  const { language, toggleLanguage } = useLanguage();

  return (
    <Button
      variant="outline"
      size="sm"
      onClick={toggleLanguage}
      className="fixed top-4 right-4 z-50 bg-card/80 backdrop-blur-sm border-border/50 hover:bg-secondary/80"
    >
      <Languages className="h-4 w-4 mr-2" />
      {language === 'en' ? 'РУС' : 'ENG'}
    </Button>
  );
};