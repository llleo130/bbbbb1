import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Rocket, DollarSign, Lightbulb, TrendingUp, Heart, FileText, Calculator, Filter } from "lucide-react";
import { Startup } from "../types";
import { startupIdeas } from "../data/startups";
import { Analytics } from "./Analytics";
import { LanguageToggle } from "./LanguageToggle";
import { useLanguage } from "../hooks/useLanguage";
import { toast } from "@/hooks/use-toast";

export const StartupGenerator = () => {
  const { language, t } = useLanguage();
  const [currentStartup, setCurrentStartup] = useState<Startup | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [favorites, setFavorites] = useState<string[]>([]);
  const [showBusinessPlan, setShowBusinessPlan] = useState(false);

  const generateStartup = () => {
    setIsGenerating(true);
    setTimeout(() => {
      const randomIndex = Math.floor(Math.random() * startupIdeas.length);
      setCurrentStartup(startupIdeas[randomIndex]);
      setIsGenerating(false);
      setShowBusinessPlan(false);
    }, 1000);
  };

  const toggleFavorite = (id: string) => {
    setFavorites(prev => {
      const newFavorites = prev.includes(id) 
        ? prev.filter(favId => favId !== id)
        : [...prev, id];
      
      toast({
        title: prev.includes(id) ? t('removeFromFavorites') : t('addToFavorites'),
        duration: 2000,
      });
      
      return newFavorites;
    });
  };

  const generateBusinessPlan = () => {
    setShowBusinessPlan(true);
    toast({
      title: t('businessPlan'),
      description: "Business plan functionality coming soon!",
      duration: 3000,
    });
  };

  const openInvestmentCalculator = () => {
    toast({
      title: t('investmentCalculator'),
      description: "Investment calculator coming soon!",
      duration: 3000,
    });
  };

  return (
    <div className="min-h-screen bg-background relative">
      <LanguageToggle />
      
      <div className="flex flex-col items-center justify-center p-6 pt-20">
        <div className="max-w-4xl w-full space-y-8">
          {/* Header */}
          <div className="text-center space-y-4">
            <div className="flex items-center justify-center space-x-3 mb-6">
              <Rocket className="h-10 w-10 text-primary" />
              <h1 className="text-5xl font-bold bg-gradient-primary bg-clip-text text-transparent">
                {t('title')}
              </h1>
            </div>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              {t('subtitle')}
            </p>
          </div>

          {/* Generate Button */}
          <div className="text-center">
            <Button 
              onClick={generateStartup}
              disabled={isGenerating}
              size="lg"
              className="bg-gradient-primary hover:shadow-glow transition-all duration-300 text-lg px-8 py-6 h-auto"
            >
              {isGenerating ? (
                <>
                  <Lightbulb className="mr-2 h-5 w-5 animate-pulse" />
                  {t('generating')}
                </>
              ) : (
                <>
                  <TrendingUp className="mr-2 h-5 w-5" />
                  {currentStartup ? t('anotherStartup') : t('generateStartup')}
                </>
              )}
            </Button>
          </div>

          {/* Startup Card */}
          {currentStartup && (
            <div className="space-y-6">
              <Card className="p-8 bg-gradient-card shadow-card border-border/50 backdrop-blur-sm animate-in slide-in-from-bottom-4 duration-500">
                <div className="space-y-6">
                  {/* Startup Name & Category */}
                  <div className="flex items-start justify-between flex-wrap gap-4">
                    <div className="flex-1">
                      <h2 className="text-3xl font-bold text-primary mb-2">
                        {currentStartup.name[language]}
                      </h2>
                      <Badge variant="secondary" className="mb-4">
                        {currentStartup.category[language]}
                      </Badge>
                    </div>
                    <div className="flex flex-col items-end space-y-2">
                      <div className="flex items-center space-x-2 text-primary">
                        <DollarSign className="h-6 w-6" />
                        <span className="text-xl font-semibold">
                          {currentStartup.monthlyProfit}
                        </span>
                      </div>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => toggleFavorite(currentStartup.id)}
                        className={favorites.includes(currentStartup.id) ? "text-red-500 border-red-500" : ""}
                      >
                        <Heart className={`h-4 w-4 mr-1 ${favorites.includes(currentStartup.id) ? "fill-current" : ""}`} />
                        {favorites.includes(currentStartup.id) ? t('removeFromFavorites') : t('addToFavorites')}
                      </Button>
                    </div>
                  </div>

                  {/* Description */}
                  <div className="space-y-3">
                    <h3 className="text-lg font-semibold text-foreground">{t('projectDescription')}</h3>
                    <p className="text-muted-foreground leading-relaxed text-base">
                      {currentStartup.description[language]}
                    </p>
                  </div>

                  {/* Action Buttons */}
                  <div className="flex flex-wrap gap-3">
                    <Button
                      variant="outline"
                      onClick={generateBusinessPlan}
                      className="flex-1 min-w-[200px]"
                    >
                      <FileText className="h-4 w-4 mr-2" />
                      {t('viewBusinessPlan')}
                    </Button>
                    <Button
                      variant="outline"
                      onClick={openInvestmentCalculator}
                      className="flex-1 min-w-[200px]"
                    >
                      <Calculator className="h-4 w-4 mr-2" />
                      {t('investmentCalculator')}
                    </Button>
                  </div>

                  {/* Profit Section */}
                  <div className="bg-secondary/50 p-4 rounded-lg border border-border/30">
                    <div className="flex items-center space-x-2 mb-2">
                      <TrendingUp className="h-5 w-5 text-primary" />
                      <h4 className="font-semibold text-foreground">{t('expectedMonthlyProfit')}</h4>
                    </div>
                    <p className="text-2xl font-bold text-primary">
                      {currentStartup.monthlyProfit}
                    </p>
                  </div>
                </div>
              </Card>

              {/* Analytics Component */}
              <Analytics startup={currentStartup} />
            </div>
          )}

          {/* Call to Action */}
          {!currentStartup && (
            <div className="text-center space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-3xl mx-auto">
                <div className="text-center space-y-2">
                  <Lightbulb className="h-8 w-8 text-primary mx-auto" />
                  <h3 className="font-semibold">{t('innovativeIdeas')}</h3>
                  <p className="text-sm text-muted-foreground">
                    {t('innovativeDesc')}
                  </p>
                </div>
                <div className="text-center space-y-2">
                  <DollarSign className="h-8 w-8 text-primary mx-auto" />
                  <h3 className="font-semibold">{t('profitableSolutions')}</h3>
                  <p className="text-sm text-muted-foreground">
                    {t('profitableDesc')}
                  </p>
                </div>
                <div className="text-center space-y-2">
                  <TrendingUp className="h-8 w-8 text-primary mx-auto" />
                  <h3 className="font-semibold">{t('marketOpportunities')}</h3>
                  <p className="text-sm text-muted-foreground">
                    {t('marketDesc')}
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* Favorites Counter */}
          {favorites.length > 0 && (
            <div className="text-center">
              <Badge variant="outline" className="text-primary border-primary">
                <Heart className="h-4 w-4 mr-1 fill-current" />
                {t('favorites')}: {favorites.length}
              </Badge>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};