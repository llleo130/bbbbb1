import { Startup } from '../types';

export const startupIdeas: Startup[] = [
  {
    id: '1',
    name: {
      en: 'EcoClean AI',
      ru: 'EcoClean AI'
    },
    description: {
      en: 'AI-powered platform for optimizing office and home cleaning. The system analyzes contamination through cameras, creates individual cleaning plans and coordinates cleaner teams. Built-in reporting system shows efficiency and time savings up to 40%.',
      ru: 'Платформа на базе ИИ для оптимизации уборки офисов и домов. Система анализирует загрязнения через камеры, составляет индивидуальные планы уборки и координирует команды клинеров. Встроенная система отчетности показывает эффективность и экономию времени до 40%.'
    },
    monthlyProfit: '$15,000 - $50,000',
    category: {
      en: 'AI & Cleaning',
      ru: 'ИИ и Уборка'
    },
    analytics: {
      marketSize: '$50B',
      competition: 'Medium',
      investmentRequired: '$100K - $500K',
      timeToProfit: '8-12 months',
      growthPotential: 8,
      riskLevel: 'Medium'
    }
  },
  {
    id: '2',
    name: {
      en: 'FoodTech Connect',
      ru: 'FoodTech Connect'
    },
    description: {
      en: 'Marketplace connecting local farmers with restaurants and cafes. Blockchain technology ensures supply transparency, while AI predicts demand. Commission from each deal plus analytics subscription.',
      ru: 'Маркетплейс для соединения локальных фермеров с ресторанами и кафе. Блокчейн-технология обеспечивает прозрачность поставок, а ИИ прогнозирует спрос. Комиссия с каждой сделки плюс подписка на аналитику.'
    },
    monthlyProfit: '$25,000 - $80,000',
    category: {
      en: 'FoodTech',
      ru: 'ФудТех'
    },
    analytics: {
      marketSize: '$120B',
      competition: 'High',
      investmentRequired: '$200K - $1M',
      timeToProfit: '12-18 months',
      growthPotential: 9,
      riskLevel: 'High'
    }
  },
  {
    id: '3',
    name: {
      en: 'MindSpace VR',
      ru: 'MindSpace VR'
    },
    description: {
      en: 'VR platform for mental health and meditation. Personalized virtual environments for relaxation, therapy and concentration training. Subscription model with individual psychologist sessions in VR.',
      ru: 'VR-платформа для ментального здоровья и медитации. Персонализированные виртуальные среды для релаксации, терапии и тренировки концентрации. Подписочная модель с возможностью индивидуальных сессий с психологами в VR.'
    },
    monthlyProfit: '$20,000 - $60,000',
    category: {
      en: 'HealthTech & VR',
      ru: 'МедТех и VR'
    },
    analytics: {
      marketSize: '$25B',
      competition: 'Low',
      investmentRequired: '$300K - $800K',
      timeToProfit: '6-10 months',
      growthPotential: 9,
      riskLevel: 'Medium'
    }
  },
  {
    id: '4',
    name: {
      en: 'CryptoLearn Academy',
      ru: 'CryptoLearn Academy'
    },
    description: {
      en: 'Educational platform for cryptocurrencies and DeFi with trading simulator. Gamified learning with real rewards, blockchain developer certification. Monetization through courses, consultations and exchange partnerships.',
      ru: 'Образовательная платформа по криптовалютам и DeFi с симулятором торговли. Геймифицированное обучение с реальными наградами, сертификация блокчейн-разработчиков. Монетизация через курсы, консультации и партнерские программы с биржами.'
    },
    monthlyProfit: '$30,000 - $100,000',
    category: {
      en: 'EdTech & Crypto',
      ru: 'ОбразТех и Крипто'
    },
    analytics: {
      marketSize: '$15B',
      competition: 'Medium',
      investmentRequired: '$150K - $600K',
      timeToProfit: '4-8 months',
      growthPotential: 10,
      riskLevel: 'High'
    }
  },
  {
    id: '5',
    name: {
      en: 'PetCare IoT',
      ru: 'PetCare IoT'
    },
    description: {
      en: 'Smart devices for pets: automatic feeders, health trackers, cameras with AI behavior analysis. Mobile app notifies about health issues. SaaS subscription plus device sales.',
      ru: 'Умные устройства для домашних животных: автоматические кормушки, трекеры здоровья, камеры с ИИ-анализом поведения. Мобильное приложение уведомляет о проблемах здоровья. SaaS-подписка плюс продажа устройств.'
    },
    monthlyProfit: '$40,000 - $120,000',
    category: {
      en: 'IoT & Pets',
      ru: 'IoT и Животные'
    },
    analytics: {
      marketSize: '$30B',
      competition: 'Medium',
      investmentRequired: '$500K - $1.5M',
      timeToProfit: '10-15 months',
      growthPotential: 8,
      riskLevel: 'Medium'
    }
  },
  {
    id: '6',
    name: {
      en: 'EnergyOptima',
      ru: 'EnergyOptima'
    },
    description: {
      en: 'AI system for optimizing energy consumption in residential complexes and offices. Analyzes usage patterns, automatically regulates heating, lighting and air conditioning. Saves up to 30% on utility bills.',
      ru: 'ИИ-система для оптимизации энергопотребления в жилых комплексах и офисах. Анализирует паттерны использования, автоматически регулирует отопление, освещение и кондиционирование. Экономия до 30% на коммунальных платежах.'
    },
    monthlyProfit: '$35,000 - $90,000',
    category: {
      en: 'GreenTech',
      ru: 'ЗеленыеТех'
    },
    analytics: {
      marketSize: '$80B',
      competition: 'High',
      investmentRequired: '$250K - $750K',
      timeToProfit: '8-12 months',
      growthPotential: 9,
      riskLevel: 'Medium'
    }
  },
  {
    id: '7',
    name: {
      en: 'RetailBot Assistant',
      ru: 'RetailBot Assistant'
    },
    description: {
      en: 'AI assistant for online stores that analyzes customer behavior and increases conversion by 25%. Personalized recommendations, support chatbot, sales analytics. SaaS model with sales commission.',
      ru: 'ИИ-ассистент для интернет-магазинов, который анализирует поведение покупателей и увеличивает конверсию на 25%. Персонализированные рекомендации, чат-бот для поддержки, аналитика продаж. Модель SaaS с комиссией от продаж.'
    },
    monthlyProfit: '$45,000 - $150,000',
    category: {
      en: 'E-commerce AI',
      ru: 'E-commerce ИИ'
    },
    analytics: {
      marketSize: '$200B',
      competition: 'High',
      investmentRequired: '$300K - $1M',
      timeToProfit: '6-10 months',
      growthPotential: 10,
      riskLevel: 'Medium'
    }
  },
  {
    id: '8',
    name: {
      en: 'SkillMatch Network',
      ru: 'SkillMatch Network'
    },
    description: {
      en: 'Platform for freelancers with AI project matching based on skills and preferences. Built-in escrow system, ratings, automatic contracts. 5% commission per deal plus premium subscription for advanced analytics.',
      ru: 'Платформа для фрилансеров с ИИ-подбором проектов на основе навыков и предпочтений. Встроенная система эскроу, рейтинги, автоматические контракты. Комиссия 5% с каждой сделки плюс премиум-подписка для расширенной аналитики.'
    },
    monthlyProfit: '$28,000 - $75,000',
    category: {
      en: 'Marketplace',
      ru: 'Маркетплейс'
    },
    analytics: {
      marketSize: '$40B',
      competition: 'High',
      investmentRequired: '$200K - $700K',
      timeToProfit: '8-14 months',
      growthPotential: 8,
      riskLevel: 'Medium'
    }
  },
  {
    id: '9',
    name: {
      en: 'FinanceFlow',
      ru: 'FinanceFlow'
    },
    description: {
      en: 'App for automating personal finances of small businesses. AI categorizes expenses, predicts cash flows, integrates with banks and tax services. Freemium model with extended features by subscription.',
      ru: 'Приложение для автоматизации личных финансов малого бизнеса. ИИ категоризирует расходы, прогнозирует денежные потоки, интегрируется с банками и налоговыми сервисами. Модель freemium с расширенными функциями по подписке.'
    },
    monthlyProfit: '$22,000 - $65,000',
    category: {
      en: 'FinTech',
      ru: 'ФинТех'
    },
    analytics: {
      marketSize: '$300B',
      competition: 'High',
      investmentRequired: '$400K - $1.2M',
      timeToProfit: '10-16 months',
      growthPotential: 9,
      riskLevel: 'High'
    }
  },
  {
    id: '10',
    name: {
      en: 'SocialMedia Ninja',
      ru: 'SocialMedia Ninja'
    },
    description: {
      en: 'Automated platform for managing small business social media. AI creates content, schedules posts, analyzes audience and competitors. Built-in templates and design tools. Subscription model with different tiers.',
      ru: 'Автоматизированная платформа для управления социальными сетями малого бизнеса. ИИ создает контент, планирует посты, анализирует аудиторию и конкурентов. Встроенные шаблоны и инструменты дизайна. Подписочная модель с различными тарифами.'
    },
    monthlyProfit: '$18,000 - $55,000',
    category: {
      en: 'SocialTech',
      ru: 'СоцТех'
    },
    analytics: {
      marketSize: '$60B',
      competition: 'High',
      investmentRequired: '$150K - $500K',
      timeToProfit: '5-9 months',
      growthPotential: 7,
      riskLevel: 'Medium'
    }
  }
];